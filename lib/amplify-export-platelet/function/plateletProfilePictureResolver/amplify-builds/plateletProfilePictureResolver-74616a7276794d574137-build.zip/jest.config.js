module.exports = {
    setupFiles: ["<rootDir>/setupTests.js"],
};
