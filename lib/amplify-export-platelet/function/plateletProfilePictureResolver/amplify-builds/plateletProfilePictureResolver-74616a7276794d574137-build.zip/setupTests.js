process.env.API_PLATELET_GRAPHQLAPIENDPOINTOUTPUT = "https://test";
process.env.API_PLATELET_GRAPHQLAPIIDOUTPUT = "test";
process.env.REGION = "someregion";
process.env.STORAGE_PLATELETSTORAGE_BUCKETNAME = "testBucket";
